"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/heartbeat.ts
var heartbeat_exports = {};
__export(heartbeat_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(heartbeat_exports);

// node_modules/@netlify/functions/dist/main.js
var import_stream = require("stream");
var import_util = require("util");
var schedule = (cron, handler2) => handler2;
var pipeline = (0, import_util.promisify)(import_stream.pipeline);

// netlify/functions/heartbeat.ts
var handler = schedule("@hourly", async () => {
  const res = await fetch(
    "https://nftmailbox-cxqzu5nt8-ghost-agents-projects.vercel.app/api/heartbeat"
  );
  if (!res.ok) {
    console.error("Heartbeat failed", res.status);
  }
  return {
    statusCode: 200
  };
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
